# Demo — Aurora Outdoors

The MyBI sample project — import it from the app (Projects → Download a sample case study), or via Import project → this folder.
